import axios from 'axios';
import React, { useState, useEffect } from 'react';

import { Link, useNavigate, useParams} from 'react-router-dom';
export default function EditUser() {

  let navigate = useNavigate();
  const {id} = useParams();

  const[user, setUser] = useState({
    name:"",
    age:"",
    email:""
  })

  const {name, age, email} =user 

  const onInputChange = (e)=>{
    setUser({...user, [e.target.name]: e.target.value}); 
  }

  useEffect(()=> {
    loadUser()
  }, []);

  const onSubmit = async(e)=>{
    e.preventDefault();
    await axios.put(`http://localhost:8080/user/${id}`, user)
    sessionStorage.setItem('user',JSON.stringify(user));
    // console.log("helllo");
    navigate("/home");
  }

  const loadUser = async()=>{
    const result= await axios.get(`http://localhost:8080/user/${id}`)
    setUser(result.data);
  }

  return (
    <div className ="container">
      <div className="row">
        <div className="custom">
          <h2 className= "text-center m-4">Edit Data</h2>
          <form onSubmit={onSubmit}>

          <div className="mb-3">
            <label htmlFor="Name" className="form-label">
              Name
            </label>
            <input type="text" className='form-control' 
            placeholder='Enter your Name' 
            name= 'name' 
            value={name} 
            onChange={(e)=> onInputChange(e)}>
            </input>

          </div>

          <div className="mb-3">
            <label htmlFor="Age" className="form-label">
              Age
            </label>
            <input type="number" className='form-control' 
            placeholder='Enter your age' 
            name= 'age'
            value={age} 
            onChange={(e)=> onInputChange(e)}>
            </input>
            
          </div>

          <div className="mb-3">
            <label htmlFor="Email" className="form-label">
              Email
            </label>
            <input type="email" className='form-control' 
            name= "email"
            placeholder='Enter your email address' 
            value={email} 
            onChange={(e)=> onInputChange(e)}>
            </input>
            
          </div>
          <button type = "submit" className='btn btn-outline-primary'>Submit</button>
          <Link  className='btn btn-outline-danger mx-2' to="/home">Cancel</Link>
          </form>
        </div>
      </div>
    </div>
  )
}
