import React, { Component, useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from "react-router-dom";
import Navbar from "./layout/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/SignUp";
import AddUser from "./users/AddUser";
import EditUser from "./users/EditUser";
import ViewUser from "./users/ViewUser";

import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

const PrivateRoute = ({ element: Component, ...rest }) => {
  const [isAuthenticated, setISAuthenticated] = useState(false);
   const [loading, setLoading] = useState (true);
  useEffect (() => {
  fetch("http://localhost:8080/isAuthenticated", {
  credentials: "include",
  })
    .then (response => response.json())
    .then (data => {
         setIsAuthenticated(data);
         setLoading(false);
  })
  
  .catch(() => {
         setIsAuthenticated(false);
         setLoading(false);
  });
  },[]);

  if(loading){
    return <div>Loading...</div>;
  }

  return isAuthenticated ? (
    <Component{...rest} />
  ) : (
    <Navigate to ="/login" replace />
  );
};

function App() {
  const location = useLocation();
  const [isAuthenticated,setIsAuthenticated]=useState(false);

  useEffect(() =>{
    setIsAuthenticated(true);
  },[location]);

  return (
    <div className="App">
      {location.pathname === "/home" && <Navbar />}
      <Routes>
        <Route exact path="/home" element={ isAuthenticated ?<Home />: <Navigate to ="/login" replace />} />
        <Route exact path="/adduser" element={isAuthenticated ?<AddUser />:<Navigate to ="/login" replace />} />
        <Route exact path="/edituser/:id" element={isAuthenticated ?<EditUser />:<Navigate to ="/login" replace />} />
        <Route exact path="/viewuser/:id" element={isAuthenticated ?<ViewUser />:<Navigate to ="/login" replace />} />

        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        <Route path="*" element={<Navigate to="/login" replace/>} />
      </Routes>
    </div>
  );
}

export default function RootApp() {
  return (
    <Router>
      <App />
    </Router>
  );
}

