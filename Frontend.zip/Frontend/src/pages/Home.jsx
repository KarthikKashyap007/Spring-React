
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export default function Home() {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(0);
  const usersPerPage = 5;
  const [totalPages, setTotalPages] = useState(0);

  // 🔹 Sorting State
  const [sortBy, setSortBy] = useState("id");
  const [sortDirection, setSortDirection] = useState("asc");

  // 🔹 Load Users from Backend
  useEffect(() => {
    loadUsers();
  }, [currentPage, sortBy, sortDirection]);

  const loadUsers = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/users`, {
        params: {
          pageNumber: currentPage,
          pageSize: usersPerPage,
          sortBy,
          sortDirection,
        },
      });

      setUsers(response.data.content);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  // 🔹 Delete User
  const deleteUser = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:8080/user/${id}`);
      alert(response.data);
      loadUsers();
    } catch (error) {
      alert(error.response?.data || "Error deleting user");
    }
  };

  // 🔹 Change Page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // 🔹 Download PDF from Backend
  const downloadPDF = async () => {
    try {
      const response = await axios({
        url: "http://localhost:8080/export/pdf",
        method: "GET",
        responseType: "blob",
      });

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "user-details-report.pdf");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error downloading PDF:", error);
      alert("Failed to download PDF.");
    }
  };

  // 🔹 Filter Users Based on Search Query
  const filteredUsers = users.filter((user) =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="table-container p-4">
      {/* 🔹 Search Section */}
      <div className="row mb-3">
        <div className="col-md-8">
          <input
            type="text"
            className="form-control"
            placeholder="Search by name or email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <button className="btn btn-primary w-100" onClick={loadUsers}>
            Search
          </button>
        </div>
      </div>

      {/* 🔹 Sorting Section */}
      <div className="row mb-4">
        <div className="col-md-6">
          <select
            className="form-control"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="id">Sort by ID</option>
            <option value="name">Sort by Name</option>
            <option value="age">Sort by Age</option>
            <option value="email">Sort by Email</option>
          </select>
        </div>

        <div className="col-md-6">
          <select
            className="form-control"
            value={sortDirection}
            onChange={(e) => setSortDirection(e.target.value)}
          >
            <option value="asc">Ascending</option>
            <option value="desc">Descending</option>
          </select>
        </div>
      </div>

      {/* 🔹 Table */}
      <table className="table">
        <thead>
          <tr>
            <th>EmpId</th>
            <th>Name</th>
            <th>Age</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.length > 0 ? (
            filteredUsers.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>{user.age}</td>
                <td>{user.email}</td>
                <td className="action">
                  <Link className="btn btn-primary" to={`/viewuser/${user.id}`}>
                    View
                  </Link>
                  <Link className="btn btn-secondary" to={`/edituser/${user.id}`}>
                    Edit
                  </Link>
                  <button
                    className="btn btn-danger"
                    onClick={() => deleteUser(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center">
                No users found
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/*  Pagination Controls */}
      <div className="pagination d-flex justify-content-center mt-3">
        {[...Array(totalPages)].map((_, index) => (
          <button
            key={index}
            onClick={() => paginate(index)}
            className={`btn ${
              currentPage === index ? "btn-primary" : "btn-light"
            } mx-1`}
          >
            {index + 1}
          </button>
        ))}
      </div>

      {/* 🔹 Download Report Button */}
      <div className="text-center mt-3">
        <button className="btn btn-success" onClick={downloadPDF}>
          Download Report
        </button>
      </div>
    </div>
  );
}

