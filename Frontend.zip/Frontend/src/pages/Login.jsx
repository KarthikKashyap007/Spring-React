import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom"; 
import axios from "axios";
// import bcrypt from bcryptjs;
const API_URL = "http://localhost:8080/";


export const AuthHeader = () => {
  const token = sessionStorage.getItem("jwtToken");
  console.log("token : ", token);
  if (token) {
    console.log("Authorization header set");
    return { Authorization: "Bearer " + token };
  } else {
    console.log("No token found");
    return {};
  }
};

export const getProtectedResource = () => {
  console.log("Calling getProtectedResource");
  const headers = AuthHeader();
  console.log("Headers: ", headers);
  return axios.get(`${API_URL}users`, {headers:  headers });
};

export default function Login() {
  const [adminId, setAdminId] = useState("");
  const [password, setPassword] = useState("");
  // const [error, setError] = useState("");

  const navigate = useNavigate();

  
  const data = {
    adminId,password,
    //  :bcrypt.hashSync(password,10),
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:8080/loginUser", data);

      if (!response.data) {
        alert("Invalid Credentials");
      } else {
        sessionStorage.setItem("isAuthenticated", "true");
        sessionStorage.setItem("jwtToken", response.data);
        alert("Login Successful");
        navigate("/home"); 
      }

      getProtectedResource()
          .then((response) => {
            console.log("Protected resource data:", response.data);
          })
          .catch((error) => {
            console.error("Error fetching protected resource:", error);
          });
        
    } catch (error) {
      console.error(error);
      if(error.response && error.response.status === 400){
        alert(error.response.data.adminId)
      }
      else if(error.response.status ==401 ){
        // alert(error.response.data.errorMessage)
        alert(error.response.data);
      }
    }
  };

  return (
    <div className="auth-container">
      <form className="auth-form" onSubmit={handleSubmit}>
        <h2 className="auth-title">Login</h2>
        <div className="form-group">
          <label>Email ID</label>
          <input
            // type="text" 
            className="form-control"
            placeholder="Enter your Email ID"
            value={adminId}
            onChange={(e) => setAdminId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary btn-block">
          Login
        </button>

        <div className="signup-prompt">
          <p>
            Don't have an account?{" "}
            <Link to="/signup" className="signup-link">
              Sign Up
            </Link>
          </p>
        </div>
      </form>
    </div>
  );
}

