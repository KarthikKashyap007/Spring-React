import axios from "axios";

const API_URL = "http://localhost:8080/";
export const AuthHeader = ()=>{
    const token = sessionStorage.getItem("jwtToken");
    console.log("token : ",token)
    if(token){
        return {Authorization: 'Bearer '+token};
    }else{
        return {};
    }
};

export const getProtectedResource = ()=>{
    return axios.get(`${API_URL}/protected`,{headers:AuthHeader()});
};