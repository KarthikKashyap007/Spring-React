package com.example.demo.service;
import com.example.demo.exception.UserAlreadyExistsException;
import com.example.demo.exception.userNotFoundException;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepo;
import org.springframework.data.domain.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.SQLOutput;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepo userrepo;

    // ✅ Fetch Users with Optional Filters, Sorting, and Pagination
    public Page<User> getUsers(String name, Long minAge, Long maxAge, String sortBy, String order, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(
                order.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC, sortBy));

        if (name != null && !name.isEmpty()) {
            return userrepo.findByNameContainingIgnoreCase(name, pageable);
        } else if (minAge != null && maxAge != null) {
            return userrepo.findByAgeBetween(minAge, maxAge, pageable);
        } else {
            return userrepo.findAll(pageable);
        }
    }

    public User saveUser(User newUser) {

        if (userrepo.existsById(newUser.getId())) {
//            System.out.println("hello2");
            throw new UserAlreadyExistsException("User with ID " + newUser.getId() + " already exists.");
        }
        return userrepo.save(newUser);
    }
//    public List<User> getAllUsers() {
//        return userrepo.findAll();
//    }

    public User getUserById(String id) {
        return userrepo.findById(id)
                .orElseThrow(() -> new userNotFoundException(id));
    }

    public Page<User> getAllUsers(int pageNumber, int pageSize) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        return userrepo.findAll(pageable);
    }


    public User updateUser(User newUser, String id) {
//        System.out.println("hello"+ id);
        return userrepo.findById(id)
                .map(user -> {
                    user.setAge(newUser.getAge());
                    user.setName(newUser.getName());
                    user.setEmail(newUser.getEmail());
                    return userrepo.save(user);
                })
                .orElseThrow(() -> new userNotFoundException(id));
    }

    public String deleteUser(String id) {
        if (!userrepo.existsById(id)) {
            throw new userNotFoundException(id);
        }
        userrepo.deleteById(id);
        return "User with id " + id + " has been deleted successfully";
    }

}
