package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.repository.AdminRepo;
import com.example.demo.request.LoginRequest;
import com.example.demo.exception.userNotFoundException;
//import com.example.demo.security.JwtUtil;
import com.example.demo.security.JwtUtil;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
     private AdminRepo adminrepo;

    @Autowired
    private JwtUtil jwtUtil;


    public Admin addUser(@Valid Admin newuser) {
        // Hash the password using SHA-256
        String hashedPassword = hashPassword(newuser.getPassword());
        newuser.setPassword(hashedPassword);
        return adminrepo.save(newuser);
    }

    // Login method
    public String loginUser(@Valid LoginRequest loginrequest) {

        // Check if admin exists by email (adminId in LoginRequest)
        Optional<Admin> admin = adminrepo.findById(loginrequest.getAdminId());

        if (admin.isEmpty()) {
            throw new userNotFoundException(loginrequest.getAdminId());
        }

        // Validate password
        Admin foundAdmin = admin.get();
//        boolean passwordMatch = passwordEncoder.matches(loginrequest.getPassword(), foundAdmin.getPassword());

        String hashedPassword = hashPassword(loginrequest.getPassword());

        if (!foundAdmin.getPassword().equals(hashedPassword)) {
            throw new userNotFoundException(loginrequest.getAdminId(), "Incorrect Password");
        }

 
        

        // Generate JWT Token and return it
//        return true;
        return jwtUtil.generateToken(foundAdmin.getEmail());

    }

    public String generateToken(String username){
        return jwtUtil.generateToken(username);
    }

    //Method to Hash the password using SHA-256
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexstring = new StringBuilder(2 * encodedhash.length);
            for (byte b : encodedhash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexstring.append('0');
                }
                hexstring.append(hex);
            }
            return hexstring.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
}

