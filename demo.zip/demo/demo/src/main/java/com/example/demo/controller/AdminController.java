
package com.example.demo.controller;

import com.example.demo.model.Admin;
import com.example.demo.request.LoginRequest;
//import com.example.demo.security.JwtUtil;
import com.example.demo.service.AdminService;
//import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AdminController {

    @Autowired
    AdminService adminservice;

//    @Autowired
//    private JwtUtil jwtUtil;

    // Endpoint to add new user
    @PostMapping("/addUser")
    @CrossOrigin("http://localhost:5173")
    public Admin addUser(@RequestBody Admin newuser) {
        return adminservice.addUser(newuser);
    }

    // Endpoint for login
    @PostMapping("/loginUser")
    @CrossOrigin("http://localhost:5173")
    public Boolean loginUser(@RequestBody LoginRequest loginrequest) {
        return adminservice.loginUser(loginrequest);
    }

}