
package com.example.demo.exception;

public class userNotFoundException extends RuntimeException {

    public userNotFoundException(String email) {
        super("Could not find user with email: " + email);
    }

    public userNotFoundException(String email, String password) {
        super("Email or Password is Incorrect " );
    }
//    public userNotFoundException( String id){
//        super("could not found user with id: " + id);// on user basis
//    }
}
