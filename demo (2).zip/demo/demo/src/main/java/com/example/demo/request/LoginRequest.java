
package com.example.demo.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

public class LoginRequest {

    @Email(regexp = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message = "Invalid email format")
    @NotEmpty(message = "Email is required")
    private String adminId;

    @NotEmpty(message = "Password is required")
    private String password;

    public LoginRequest(String adminId, String password) {
        this.adminId = adminId;
        this.password = password;
    }

    public LoginRequest() {}

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
