package com.example.demo.controller;
import com.example.demo.model.User;
//import com.example.demo.repository.UserRepo;
import com.example.demo.service.ExportService;
import com.example.demo.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class UserController {

    @Autowired
    private UserService userservice;
    @GetMapping
    public ResponseEntity<Page<User>> getUsers(
            @RequestParam(required = false) String name,  // 🔍 Filter by Name
            @RequestParam(required = false) Long minAge,  // 🔍 Min Age
            @RequestParam(required = false) Long maxAge,  // 🔍 Max Age
            @RequestParam(defaultValue = "id") String sortBy,  // 🔄 Sort Field
            @RequestParam(defaultValue = "asc") String order,  // 🔄 Sorting Order (asc/desc)
            @RequestParam(defaultValue = "0") int page,  // 📄 Page Number
            @RequestParam(defaultValue = "10") int size  // 📄 Page Size
    ) {
        return ResponseEntity.ok(userservice.getUsers(name, minAge, maxAge, sortBy, order, page, size));
    }

    @Autowired
    private ExportService exportService;

    @PostMapping("/user")
    public User addUser(@Valid @RequestBody User newUser) {
        return userservice.saveUser(newUser);
    }

//    @GetMapping("/users")
//    public List<User> getAllUsers() {
//        return userservice.getAllUsers();
//    }

    @GetMapping("/users")
    public ResponseEntity<Page<User>> getAlLUsers(
            @RequestParam(value = "pageNumber", defaultValue = "0") int pageNumber,
            @RequestParam (value = "pageSize", defaultValue = "5") int pageSize) {
        Page<User> users = userservice.getAllUsers(pageNumber, pageSize);
        return ResponseEntity.ok(users);
    }

    @GetMapping("/user/{id}")
    public User getUserById(@PathVariable String id) {
        return userservice.getUserById(id);
    }
    
    

    @PutMapping("/user/{id}")
    public User updateUser(@Valid @RequestBody User newUser, @PathVariable String  id) {
        return userservice.updateUser(newUser, id);
    }

    @DeleteMapping("/user/{id}")
    public String deleteUser(@PathVariable String id) {
        return userservice.deleteUser(id);
    }


    @GetMapping("/export/pdf")
    @CrossOrigin(origins = "http://localhost:5173")
    public ResponseEntity<byte[]> exportToPDF() throws IOException {
        return exportService.exportToPDF();
    }



}

