 
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Link } from "react-router-dom";

// export default function Home() {
//   const [users, setUsers] = useState([]);
//   const [searchQuery, setSearchQuery] = useState("");
//   const [currentPage, setCurrentPage] = useState(1);
//   const usersPerPage = 5;

//   useEffect(() => {
//     loadUsers();
//   }, []);

//   const loadUsers = async () => {
//     const result = await axios.get("http://localhost:8080/users");
//     setUsers(result.data);
//   };

//   const deleteUser = async (id) => {
//     try {
//       const response = await axios.delete(`http://localhost:8080/user/${id}`);
//       window.alert(response.data);
//       loadUsers();
//     } catch (error) {
//       window.alert(error.response.data);
//     }
//   };

//   const filteredUsers = users.filter((user) =>
//     `${user.id} ${user.name} ${user.email}`
//       .toLowerCase()
//       .includes(searchQuery.toLowerCase())
//   );

//   // Pagination Logic
//   const indexOfLastUser = currentPage * usersPerPage;
//   const indexOfFirstUser = indexOfLastUser - usersPerPage;
//   const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

//   const paginate = (pageNumber) => setCurrentPage(pageNumber);

//   // ✅ Function to Download PDF from Backend
//   const downloadPDF = async () => {
//     try {
//       const response = await axios({
//         url: "http://localhost:8080/export/pdf", // Make sure this endpoint exists in your backend
//         method: "GET",
//         responseType: "blob", // Important: Handle binary data
//       });

//       // Create a link element to trigger download
//       const url = window.URL.createObjectURL(new Blob([response.data]));
//       const link = document.createElement("a");
//       link.href = url;5757
//       link.setAttribute("download", "user-details-report.pdf");
//       document.body.appendChild(link);
//       link.click();
//       document.body.removeChild(link);
//     } catch (error) {
//       console.error("Error downloading PDF:", error);
//       window.alert("Failed to download PDF.");
//     }
//   };

//   return (
//     <div className="table-container p-4">
//       {/* Search Bar and Download Button */}
//       <div className="row mb-4">
//         <div className="col-12 d-flex justify-end items-center mb-4">
//           <input
//             type="text"
//             placeholder="Search by ID, Name, or Email..."
//             value={searchQuery}
//             onChange={(e) => setSearchQuery(e.target.value)}
//             className="form-control w-50"
//           />
//           <button className="btn btn-success" onClick={downloadPDF}>
//             Download Report
//           </button>
//         </div>
//       </div>

//       <table className="table">
//         <thead>
//           <tr>
//             <th>EmpId</th>
//             <th>Name</th>
//             <th>Age</th>
//             <th>Email</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {currentUsers.map((user) => (
//             <tr key={user.id}>
//               <td>{user.id}</td>
//               <td>{user.name}</td>
//               <td>{user.age}</td>
//               <td>{user.email}</td>

//               <td className="action">
//                 <Link className="btn btn-primary" to={`/viewuser/${user.id}`}>
//                   View
//                 </Link>
//                 <Link className="btn btn-secondary" to={`/edituser/${user.id}`}>
//                   Edit
//                 </Link>
//                 <button
//                   className="btn btn-danger"
//                   onClick={() => deleteUser(user.id)}
//                 >
//                   Delete
//                 </button>
//               </td>
//             </tr>
//           ))}
//           {filteredUsers.length === 0 && (
//             <tr>
//               <td colSpan="5" className="text-center">
//                 No users found
//               </td>
//             </tr>
//           )}
//         </tbody>
//       </table>

//       {/* Pagination Controls */}
//       <div className="pagination d-flex justify-content-center mt-3">
//         {[...Array(Math.ceil(filteredUsers.length / usersPerPage))].map(
//           (_, index) => (
//             <button
//               key={index}
//               onClick={() => paginate(index + 1)}
//               className={`btn ${
//                 currentPage === index + 1 ? "btn-primary" : "btn-light"
//               } mx-1`}
//             >
//               {index + 1}
//             </button>
//           )
//         )}
//       </div>
//     </div>
//   );
// }

import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export default function Home() {
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(0); // Change from 1 to 0 for backend compatibility
  const usersPerPage = 5;
  const [totalPages, setTotalPages] = useState(0);

  useEffect(() => {
    loadUsers();
  }, [currentPage]); // Re-fetch users when page changes

  // ✅ Fetch Users with Pagination
  const loadUsers = async () => {
    try {
      const response = await axios.get(
        `http://localhost:8080/users?pageNumber=${currentPage}&pageSize=${usersPerPage}`
      );
      setUsers(response.data.content);
      setTotalPages(response.data.totalPages);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  // ✅ Delete User
  const deleteUser = async (id) => {
    try {
      const response = await axios.delete(`http://localhost:8080/user/${id}`);
      alert(response.data);
      loadUsers();
    } catch (error) {
      alert(error.response?.data || "Error deleting user");
    }
  };

  // ✅ Filter Users (Client-Side Search)
  const filteredUsers = users.filter((user) =>
    `${user.id} ${user.name} ${user.email}`
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  );

  // ✅ Change Page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // ✅ Download PDF from Backend
  const downloadPDF = async () => {
    try {
      const response = await axios({
        url: "http://localhost:8080/export/pdf",
        method: "GET",
        responseType: "blob",
      });

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", "user-details-report.pdf");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error downloading PDF:", error);
      alert("Failed to download PDF.");
    }
  };

  return (
    <div className="table-container p-4">
      {/* Search Bar & Download Button */}
      <div className="row mb-4">
        <div className="col-12 d-flex align-items-center">
          <input
            type="text"
            placeholder="Search by ID, Name, or Email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="form-control w-50"
          />
          <button className="btn btn-success" onClick={downloadPDF}>
            Download Report
          </button>
        </div>
      </div>

      {/* Table */}
      <table className="table">
        <thead>
          <tr>
            <th>EmpId</th>
            <th>Name</th>
            <th>Age</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.name}</td>
              <td>{user.age}</td>
              <td>{user.email}</td>
              <td className="action">
                <Link className="btn btn-primary" to={`/viewuser/${user.id}`}>
                  View
                </Link>
                <Link className="btn btn-secondary" to={`/edituser/${user.id}`}>
                  Edit
                </Link>
                <button
                  className="btn btn-danger"
                  onClick={() => deleteUser(user.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
          {filteredUsers.length === 0 && (
            <tr>
              <td colSpan="5" className="text-center">
                No users found
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="pagination d-flex justify-content-center mt-3">
        {[...Array(totalPages)].map((_, index) => (
          <button
            key={index}
            onClick={() => paginate(index)}
            className={`btn ${
              currentPage === index ? "btn-primary" : "btn-light"
            } mx-1`}
          >
            {index + 1}
          </button>
        ))}
      </div>
    </div>
  );
}

