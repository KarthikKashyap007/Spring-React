import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom"; 
import axios from "axios";
// import bcrypt from bcryptjs;

export default function Login() {
  const [adminId, setAdminId] = useState("");
  const [password, setPassword] = useState("");
  // const [error, setError] = useState("");

  const navigate = useNavigate();

  
  const data = {
    adminId,password,
    //  :bcrypt.hashSync(password,10),
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:8080/loginUser", data);

      if (!response.data) {
        alert("Invalid Credentials");
      } else {
        alert("Login Successful");
        navigate("/home"); 
      }
    } catch (error) {
      console.error(error);
      if(error.response && error.response.status === 400){
        alert(error.response.data.adminId)
      }
      else if(error.response.status ==401 ){
        alert(error.response.data.errorMessage)
      }
    }
  };

  return (
    <div className="auth-container">
      <form className="auth-form" onSubmit={handleSubmit}>
        <h2 className="auth-title">Login</h2>
        <div className="form-group">
          <label>Email ID</label>
          <input
            // type="text" 
            className="form-control"
            placeholder="Enter your Email ID"
            value={adminId}
            onChange={(e) => setAdminId(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            className="form-control"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary btn-block">
          Login
        </button>

        <div className="signup-prompt">
          <p>
            Don't have an account?{" "}
            <Link to="/signup" className="signup-link">
              Sign Up
            </Link>
          </p>
        </div>
      </form>
    </div>
  );
}

