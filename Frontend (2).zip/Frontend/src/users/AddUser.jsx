import axios from 'axios';
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function AddUser() {

  let navigate = useNavigate();
  const [user, setUser] = useState({
    id: "",
    name: "",
    age: "",
    email: ""
  });
  const [errors,setErrors]=useState({})

  const { id, name, age, email } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
    setErrors({...errors,[e.target.name]:""})
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    try {
        await axios.post("http://localhost:8080/user", user);
        sessionStorage.setItem('user',JSON.stringify(user));
        navigate("/home");
    } catch(error) {
      // console.log("Error:",error)
      console.log("Error:", error); 
        if(error.response.status === 400){
          //console.log(error);
          alert(error.response.data.age);
        }
        else if(error.status== 409){
          alert(error.response.data.message);
        }
        else {
            alert("An unexpected error occurred.");
        }
    }
};

  return (
    <div className="container">
      <div className="row">
        <div className='custom'>
          <h2 className="text-center m-4">Customer Data</h2>

          <form onSubmit={onSubmit}>
            <div className="mb-3">
              <label htmlFor="id">EmpID</label>
              <input
                type="number"
                className={`form-control ${errors.id ? 'is-valid' : ''}`}
                placeholder="Enter user EmpID"
                name="id"
                value={id}
                onChange={(e) => onInputChange(e)}
                required
              />
              {errors.id && <div className="invalid-feedback">{errors.id}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="Name" className="form-label">Name</label>
              <input
                type="text"
                className={`form-control ${errors.name? 'is-valid' : ' '}`}
                placeholder="Enter your Name"
                name="name"
                value={name}
                onChange={(e) => onInputChange(e)}
                required
              />
              {errors.name && <div className="invalid-feedback"> {errors.name}</div>}
            </div>

            <div className="mb-3">
              <label htmlFor="Age">Age</label>
              <input
                type="number"
                className={`form-control ${errors.age? 'is-valid' : '' }`}
                placeholder="Enter your age"
                name="age"
                value={age}
                onChange={(e) => onInputChange(e)}
                required
              />
              {errors.age && <div className="invalid-feedback"> {errors.age}</div>}
            </div>

            <div className="mb-3">
              <label>Email</label>
              <input
                type="email"
                name="email"
                className={`form-control ${errors.email? 'is-valid' : '' }`}
                placeholder="Enter your email"
                value={email}
                onChange={(e) => onInputChange(e)}
                autoComplete="off"
                required
              />
              {errors.email && <div className="invalid-feedback"> {errors.email}</div>}
            </div>

            <button type="submit" className="btn btn-outline-primary">Submit</button>
            <Link className="btn btn-outline-danger mx-2" to="/home">Cancel</Link>
            {errors.general && <div className="text-danger mt-2"> {errors.general}</div>}
          </form>
        </div>
      </div>
    </div>
  );
}
